package com.focustube.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.text.InputType
import android.view.View

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var linkInput: EditText
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 24, 39)
        window.navigationBarColor = Color.rgb(16, 24, 39)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(10))
            setBackgroundColor(Color.rgb(246, 248, 252))
        }

        val title = TextView(this).apply {
            text = "FocusTube"
            textSize = 25f
            setTextColor(Color.rgb(24, 35, 58))
            gravity = Gravity.CENTER_VERTICAL
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(42)))

        val subtitle = TextView(this).apply {
            text = "Paste a YouTube video or playlist link"
            textSize = 14f
            setTextColor(Color.rgb(85, 96, 116))
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(30)))

        linkInput = EditText(this).apply {
            hint = "https://youtube.com/watch?v=..."
            textSize = 14f
            singleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(linkInput, LinearLayout.LayoutParams(-1, dp(52)))

        val playButton = Button(this).apply {
            text = "PLAY LINK"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(49, 87, 213)))
            setOnClickListener { openPastedLink() }
        }
        val btnParams = LinearLayout.LayoutParams(-1, dp(48))
        btnParams.topMargin = dp(8)
        root.addView(playButton, btnParams)

        val note = TextView(this).apply {
            text = "No search, feed, or recommendations in this app. Playback depends on YouTube embed availability."
            textSize = 12f
            setTextColor(Color.rgb(95, 105, 122))
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(note, LinearLayout.LayoutParams(-1, -2))

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                    if (customView != null) { callback.onCustomViewHidden(); return }
                    customView = view
                    customCallback = callback
                    (window.decorView as ViewGroup).addView(view, ViewGroup.LayoutParams(-1, -1))
                    @Suppress("DEPRECATION")
                    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                }
                override fun onHideCustomView() {
                    val v = customView ?: return
                    (window.decorView as ViewGroup).removeView(v)
                    customView = null
                    @Suppress("DEPRECATION")
                    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
                    customCallback?.onCustomViewHidden()
                    customCallback = null
                }
            }
            setBackgroundColor(Color.BLACK)
        }
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun openPastedLink() {
        val raw = linkInput.text.toString().trim()
        if (raw.isBlank()) {
            Toast.makeText(this, "Pehle YouTube link paste karo", Toast.LENGTH_SHORT).show()
            return
        }
        val parsed = parseYoutubeLink(raw)
        if (parsed == null) {
            Toast.makeText(this, "Valid YouTube video ya playlist link paste karo", Toast.LENGTH_LONG).show()
            return
        }
        val embedUrl = when {
            parsed.videoId != null -> {
                val listParam = parsed.playlistId?.let { "&list=$it" } ?: ""
                "https://www.youtube-nocookie.com/embed/${parsed.videoId}?autoplay=1$listParam&rel=0"
            }
            parsed.playlistId != null ->
                "https://www.youtube-nocookie.com/embed/videoseries?list=${parsed.playlistId}&autoplay=1&rel=0"
            else -> null
        }
        if (embedUrl == null) return
        val html = """
            <!doctype html><html><head>
            <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
            <style>html,body{margin:0;padding:0;background:#000;width:100%;height:100%;overflow:hidden}
            iframe{border:0;width:100%;height:100%;}</style></head><body>
            <iframe src="$embedUrl" title="YouTube player"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
            </body></html>
        """.trimIndent()
        webView.loadDataWithBaseURL("https://focustube.app/", html, "text/html", "UTF-8", null)
    }

    private data class YoutubeLink(val videoId: String?, val playlistId: String?)

    private fun parseYoutubeLink(raw: String): YoutubeLink? {
        val normalized = if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://$raw"
        val uri = try { android.net.Uri.parse(normalized) } catch (_: Exception) { return null }
        val host = (uri.host ?: "").lowercase()
        val validHost = host == "youtube.com" || host.endsWith(".youtube.com") ||
                host == "youtu.be" || host == "youtube-nocookie.com"
        if (!validHost) return null

        var videoId: String? = null
        var playlistId: String? = uri.getQueryParameter("list")

        if (host == "youtu.be") {
            videoId = uri.pathSegments.firstOrNull()
        } else {
            videoId = uri.getQueryParameter("v")
            if (videoId == null) {
                val segments = uri.pathSegments
                val embedIndex = segments.indexOf("embed")
                if (embedIndex >= 0 && embedIndex + 1 < segments.size && segments[embedIndex + 1] != "videoseries") {
                    videoId = segments[embedIndex + 1]
                }
                if (segments.firstOrNull() == "shorts" && segments.size > 1) videoId = segments[1]
            }
            if (uri.path?.contains("playlist") == true && playlistId == null) {
                playlistId = uri.getQueryParameter("list")
            }
        }

        if (videoId != null && !videoId.matches(Regex("[A-Za-z0-9_-]{11}"))) videoId = null
        if (playlistId != null && !playlistId.matches(Regex("[A-Za-z0-9_-]+"))) playlistId = null
        return if (videoId != null || playlistId != null) YoutubeLink(videoId, playlistId) else null
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (customView != null) {
            webView.webChromeClient?.onHideCustomView()
        } else {
            super.onBackPressed()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}

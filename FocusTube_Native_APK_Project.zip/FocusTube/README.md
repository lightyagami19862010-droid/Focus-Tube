# FocusTube (native Android app)
Standalone app: YouTube lecture links play inside the app's own WebView. No browser needed.
Build: GitHub Actions (.github/workflows/build.yml) or Android Studio -> Build APK(s).
